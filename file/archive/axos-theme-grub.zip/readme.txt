Extract "axos" in :
    for grub:
        /boot/grub/themes

    for grub2:
        /boot/grub/themes

    Make sure to add/change this line in /etc/default/grub :
        GRUB_THEME=/boot/grub2/themes/hollow-grub/theme.txt
